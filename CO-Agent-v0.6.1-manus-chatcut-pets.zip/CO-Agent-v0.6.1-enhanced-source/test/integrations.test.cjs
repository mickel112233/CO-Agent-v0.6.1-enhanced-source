const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const integrations = require('../electron/integrations.cjs');

test('integration catalog keeps optional tools optional', () => {
  assert.equal(integrations.TOOLS.tesseract.required, false);
  assert.equal(integrations.TOOLS.hyperframes.required, false);
  assert.equal(integrations.TOOLS.ollama.required, true);
  assert.equal(integrations.TOOLS.luxtts.required, false);
  assert.equal(Object.hasOwn(integrations.TOOLS, 'piper'), false);
  assert.equal(integrations.TOOLS.hyperframes.install, 'npm');
});

test('repository URLs are restricted to HTTPS GitHub owner/repo URLs', () => {
  assert.match('https://github.com/openclaw/openclaw', integrations.GITHUB_HTTPS);
  assert.match('https://github.com/openclaw/openclaw.git', integrations.GITHUB_HTTPS);
  assert.doesNotMatch('https://example.com/owner/repo', integrations.GITHUB_HTTPS);
  assert.doesNotMatch('file:///C:/private/repo', integrations.GITHUB_HTTPS);
  assert.doesNotMatch('https://github.com/owner/repo?cmd=bad', integrations.GITHUB_HTTPS);
});

test('branch and tag references reject option-like and path traversal values', () => {
  assert.match('main', integrations.REF_RE);
  assert.match('release/v1.2.0', integrations.REF_RE);
  assert.doesNotMatch('--upload-pack=malicious', integrations.REF_RE);
  assert.doesNotMatch('../secret', integrations.REF_RE);
});

test('repository import rejects invalid hosts before touching the filesystem', async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'co-agent-integrations-'));
  try {
    await assert.rejects(() => integrations.installRepo({ url: 'https://example.com/x/y' }, dir), /public GitHub repository URL/);
    await assert.rejects(() => integrations.installRepo({ url: 'https://github.com/x/y', ref: '--upload-pack=evil' }, dir), /unsupported characters/);
  } finally { await fs.rm(dir, { recursive: true, force: true }); }
});

test('installed repository skill text is only returned from managed imported repos and is capped', async () => {
  const userData = await fs.mkdtemp(path.join(os.tmpdir(), 'co-agent-skill-'));
  const root = path.join(userData, 'extensions', 'sample-skill');
  await fs.mkdir(root, { recursive: true });
  try {
    await fs.writeFile(path.join(root, '.co-agent-source.json'), JSON.stringify({ url: 'https://github.com/example/skill' }));
    await fs.writeFile(path.join(root, 'SKILL.md'), '# Helpful skill\nUse clear steps.');
    const result = await integrations.getSkillContents(['sample-skill', '../outside', 'not-installed'], userData);
    assert.equal(result.length, 1);
    assert.match(result[0].content, /Helpful skill/);
    await fs.writeFile(path.join(root, 'SKILL.md'), 'x'.repeat(30001));
    const capped = await integrations.getSkillContents(['sample-skill'], userData);
    assert.equal(capped.length, 0);
  } finally { await fs.rm(userData, { recursive: true, force: true }); }
});

test('repository skill reader ignores symlinked skill files', async (t) => {
  const userData = await fs.mkdtemp(path.join(os.tmpdir(), 'co-agent-skill-link-'));
  const root = path.join(userData, 'extensions', 'linked-skill');
  const outside = path.join(userData, 'outside.md');
  await fs.mkdir(root, { recursive: true });
  try {
    await fs.writeFile(outside, '# Do not read\nprivate text');
    await fs.writeFile(path.join(root, '.co-agent-source.json'), JSON.stringify({ url: 'https://github.com/example/linked-skill' }));
    try {
      await fs.symlink(outside, path.join(root, 'SKILL.md'), 'file');
    } catch (error) {
      if (['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) {
        t.skip('This environment does not permit creating symlinks.');
        return;
      }
      throw error;
    }
    const result = await integrations.getSkillContents(['linked-skill'], userData);
    assert.equal(result.length, 0);
  } finally {
    await fs.rm(userData, { recursive: true, force: true });
  }
});

test('repository tree review rejects symlinks and oversized files before exposing imported content', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'co-agent-repo-limits-'));
  const outside = path.join(root, 'outside.txt');
  const repo = path.join(root, 'repo');
  await fs.mkdir(repo);
  try {
    await fs.writeFile(outside, 'private');
    await fs.writeFile(path.join(repo, 'README.md'), 'safe');
    assert.deepEqual(await integrations.validateRepositoryTree(repo), { fileCount: 1, totalBytes: 4 });
    try { await fs.symlink(outside, path.join(repo, 'linked.txt'), 'file'); }
    catch (error) {
      if (['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) { t.skip('Symlinks unavailable in this environment'); return; }
      throw error;
    }
    await assert.rejects(() => integrations.validateRepositoryTree(repo), /symbolic links/i);
    await fs.unlink(path.join(repo, 'linked.txt'));
    await fs.writeFile(path.join(repo, 'large.bin'), Buffer.alloc(integrations.MAX_REPO_FILE_BYTES + 1));
    await assert.rejects(() => integrations.validateRepositoryTree(repo), /exceeds 25 MB/i);
  } finally { await fs.rm(root, { recursive: true, force: true }); }
});
